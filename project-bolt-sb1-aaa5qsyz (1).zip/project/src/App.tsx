import React, { useState } from 'react';
import { Globe2, Users, Briefcase, GraduationCap, ArrowRight, Building2, X, CheckCircle } from 'lucide-react';
import { supabase } from './lib/supabase';

type ModalType = 'business' | 'talent' | null;

interface FormField {
  name: string;
  label: string;
  type: string;
  required: boolean;
}

const formFields: Record<ModalType, FormField[]> = {
  business: [
    { name: 'name', label: 'Full Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
    { name: 'company', label: 'Company Name', type: 'text', required: true },
    { name: 'location', label: 'Location', type: 'text', required: true },
    { name: 'phone', label: 'Phone Number', type: 'tel', required: true },
    { name: 'industry', label: 'Industry', type: 'text', required: true },
    { name: 'size', label: 'Company Size', type: 'text', required: true },
    { name: 'website', label: 'Company Website', type: 'url', required: false }
  ],
  talent: [
    { name: 'name', label: 'Full Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
    { name: 'role', label: 'Current Role', type: 'text', required: true },
    { name: 'location', label: 'Location', type: 'text', required: true },
    { name: 'phone', label: 'Phone Number', type: 'tel', required: true },
    { name: 'experience', label: 'Years of Experience', type: 'number', required: true },
    { name: 'skills', label: 'Key Skills', type: 'text', required: true },
    { name: 'linkedin', label: 'LinkedIn Profile', type: 'url', required: false }
  ],
  null: []
};

const businessSteps = [
  {
    step: 1,
    title: 'Submit the Form',
    description: 'Tell us about your company needs.'
  },
  {
    step: 2,
    title: 'Interview with Our Staff',
    description: 'Discuss your requirements in detail.'
  },
  {
    step: 3,
    title: 'Review Matches',
    description: 'We present pre-screened candidates.'
  },
  {
    step: 4,
    title: 'Hire & Onboard',
    description: 'Select your preferred candidate and begin collaboration.'
  }
];

const talentSteps = [
  {
    step: 1,
    title: 'Submit the Form',
    description: 'Provide your skills, experience, and career interests.'
  },
  {
    step: 2,
    title: 'Complete Assessment Process',
    description: 'Showcase your skills through our evaluation.'
  },
  {
    step: 3,
    title: 'Interview with Our Staff',
    description: 'Help us understand your background and goals.'
  },
  {
    step: 4,
    title: 'Get Matched',
    description: 'Connect with companies looking for your skill set.'
  }
];

function App() {
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    try {
      if (activeModal === 'business') {
        const { error: submitError } = await supabase
          .from('businesses')
          .insert([{
            name: formData.name,
            email: formData.email,
            company_name: formData.company,
            location: formData.location,
            phone: formData.phone,
            industry: formData.industry,
            size: formData.size,
            website: formData.website || null
          }]);
          
        if (submitError) throw submitError;
      } else {
        const { error: submitError } = await supabase
          .from('talent')
          .insert([{
            name: formData.name,
            email: formData.email,
            job_role: formData.role,
            location: formData.location,
            phone: formData.phone,
            experience: formData.experience,
            skills: formData.skills,
            linkedin: formData.linkedin || null
          }]);
          
        if (submitError) throw submitError;
      }

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setActiveModal(null);
        setFormData({});
      }, 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const Modal = ({ type }: { type: 'business' | 'talent' }) => {
    if (success) {
      return (
        <div className="fixed inset-0 bg-emerald-500 flex items-center justify-center z-50">
          <div className="text-center text-white">
            <CheckCircle className="w-24 h-24 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-4">Registration Successful!</h2>
            <p className="text-xl">Thank you for joining Project Forward Africa.</p>
          </div>
        </div>
      );
    }

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-xl w-full p-6 relative max-h-[90vh] overflow-y-auto">
          <button 
            onClick={() => setActiveModal(null)}
            className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
          <h2 className="text-2xl font-bold mb-6">
            {type === 'business' ? 'Register Your Business' : 'Join as Talent'}
          </h2>
          {error && (
            <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-700 rounded-lg">
              {error}
            </div>
          )}
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {formFields[type].map((field) => (
              <div key={field.name} className={field.name === 'website' || field.name === 'linkedin' ? 'col-span-2' : ''}>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {field.label}
                  {field.required && <span className="text-red-500">*</span>}
                </label>
                <input
                  type={field.type}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required={field.required}
                  autoComplete="on"
                  spellCheck="false"
                  autoCapitalize="off"
                />
              </div>
            ))}
            <button
              type="submit"
              disabled={isSubmitting}
              className={`col-span-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-semibold mt-6 ${
                isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? 'Submitting...' : 'Submit'}
            </button>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-white">
      {activeModal && <Modal type={activeModal} />}
      
      {/* Hero Section */}
      <div 
        className="relative h-screen flex items-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url("https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto px-6">
          <div className="flex items-center mb-12">
            <img src="/logo.svg" alt="Project Forward Africa Logo" className="w-16 h-16 mr-4" />
            <h1 className="text-3xl font-bold text-white">Project Forward Africa</h1>
          </div>
          <div className="max-w-3xl">
            <h2 className="text-5xl font-bold text-white mb-6">
              Bridging Africa's Talent with Global Opportunities
            </h2>
            <p className="text-xl text-gray-200 mb-8">
              Project Forward Africa connects exceptional African professionals with worldwide businesses, 
              creating meaningful employment opportunities and driving economic growth.
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => setActiveModal('business')}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold flex items-center gap-2"
              >
                Find Talent <ArrowRight size={20} />
              </button>
              <button 
                onClick={() => setActiveModal('talent')}
                className="bg-white hover:bg-gray-100 text-blue-600 px-8 py-3 rounded-lg font-semibold"
              >
                Join as Talent
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Impact</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We're transforming Africa's workforce by creating sustainable connections 
              between talent and opportunities.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="bg-blue-100 w-12 h-12 flex items-center justify-center rounded-lg mb-6">
                <Users className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Talent Matching</h3>
              <p className="text-gray-600">
                Connecting skilled African professionals with global businesses seeking top talent.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="bg-blue-100 w-12 h-12 flex items-center justify-center rounded-lg mb-6">
                <GraduationCap className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Skill Development</h3>
              <p className="text-gray-600">
                Providing training and resources to enhance professional capabilities.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="bg-blue-100 w-12 h-12 flex items-center justify-center rounded-lg mb-6">
                <Globe2 className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Global Network</h3>
              <p className="text-gray-600">
                Building bridges between African talent and international opportunities.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our process is designed to create successful matches between talent and opportunities.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-3">
                <Building2 className="text-blue-600" />
                For Businesses
              </h3>
              <div className="space-y-4">
                {businessSteps.map((step) => (
                  <div key={step.step} className="flex items-start gap-4">
                    <div className="bg-blue-100 text-blue-600 w-8 h-8 flex items-center justify-center rounded-full flex-shrink-0">
                      {step.step}
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">{step.title}</h4>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-3">
                <Users className="text-blue-600" />
                For Talent
              </h3>
              <div className="space-y-4">
                {talentSteps.map((step) => (
                  <div key={step.step} className="flex items-start gap-4">
                    <div className="bg-blue-100 text-blue-600 w-8 h-8 flex items-center justify-center rounded-full flex-shrink-0">
                      {step.step}
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">{step.title}</h4>
                      <p className="text-gray-600">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-50 py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Join Project Forward Africa today and be part of the movement transforming 
            Africa's professional landscape.
          </p>
          <div className="flex gap-4 justify-center">
            <button 
              onClick={() => setActiveModal('business')}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold"
            >
              Register as Business
            </button>
            <button 
              onClick={() => setActiveModal('talent')}
              className="bg-white hover:bg-gray-100 text-blue-600 border-2 border-blue-600 px-8 py-3 rounded-lg font-semibold"
            >
              Join as Talent
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <img src="/logo.svg" alt="Project Forward Africa Logo" className="w-8 h-8 mr-2" />
                <h3 className="text-white font-semibold">Project Forward Africa</h3>
              </div>
              <p className="text-sm">
                Empowering Africa's workforce through global connections and opportunities.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">For Businesses</h4>
              <ul className="space-y-2 text-sm">
                <li>Hire Talent</li>
                <li>Pricing</li>
                <li>Case Studies</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">For Talent</h4>
              <ul className="space-y-2 text-sm">
                <li>Find Jobs</li>
                <li>Skills Training</li>
                <li>Success Stories</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>About Us</li>
                <li>Contact</li>
                <li>Blog</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-sm text-center">
            © 2025 Project Forward Africa. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;