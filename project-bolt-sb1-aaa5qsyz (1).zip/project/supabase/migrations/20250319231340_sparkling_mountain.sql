/*
  # Add new fields to businesses and talent tables

  1. Changes
    - Add to businesses table:
      - industry (text)
      - size (text)
      - website (text, nullable)
    
    - Add to talent table:
      - experience (text)
      - skills (text)
      - linkedin (text, nullable)

  2. Security
    - Existing RLS policies will automatically apply to new columns
*/

-- Add new columns to businesses table
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'businesses' AND column_name = 'industry'
  ) THEN
    ALTER TABLE businesses ADD COLUMN industry text;
    ALTER TABLE businesses ADD COLUMN size text;
    ALTER TABLE businesses ADD COLUMN website text;
  END IF;
END $$;

-- Add new columns to talent table
DO $$ 
BEGIN 
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'talent' AND column_name = 'experience'
  ) THEN
    ALTER TABLE talent ADD COLUMN experience text;
    ALTER TABLE talent ADD COLUMN skills text;
    ALTER TABLE talent ADD COLUMN linkedin text;
  END IF;
END $$;