/*
  # Initial schema setup for Project Forward Africa

  1. New Tables
    - `businesses`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text, unique)
      - `company_name` (text)
      - `location` (text)
      - `phone` (text)
      - `created_at` (timestamp)
      
    - `talent`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text, unique)
      - `job_role` (text)
      - `location` (text)
      - `phone` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read their own data
    - Add policies for service role to insert data
*/

-- Create businesses table
CREATE TABLE IF NOT EXISTS businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  company_name text NOT NULL,
  location text NOT NULL,
  phone text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create talent table
CREATE TABLE IF NOT EXISTS talent (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  job_role text NOT NULL,
  location text NOT NULL,
  phone text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE talent ENABLE ROW LEVEL SECURITY;

-- Create policies for businesses
CREATE POLICY "Businesses can read own data"
  ON businesses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Allow insert to businesses"
  ON businesses
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Create policies for talent
CREATE POLICY "Talent can read own data"
  ON talent
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Allow insert to talent"
  ON talent
  FOR INSERT
  TO anon
  WITH CHECK (true);